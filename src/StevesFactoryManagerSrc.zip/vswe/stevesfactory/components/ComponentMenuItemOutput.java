package vswe.stevesfactory.components;


public class ComponentMenuItemOutput extends ComponentMenuItem {
    public ComponentMenuItemOutput(FlowComponent parent) {
        super(parent);

        setFirstRadioButtonSelected(false);
    }
}
