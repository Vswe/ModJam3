package vswe.stevesfactory.network;


public interface IComponentNetworkReader {
    void readNetworkComponent(DataReader dr);
}
