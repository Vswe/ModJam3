package vswe.stevesfactory.proxy;


public class ClientProxy extends CommonProxy {
}
