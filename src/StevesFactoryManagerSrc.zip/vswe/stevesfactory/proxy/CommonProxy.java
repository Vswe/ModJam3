package vswe.stevesfactory.proxy;


public class CommonProxy {
}
